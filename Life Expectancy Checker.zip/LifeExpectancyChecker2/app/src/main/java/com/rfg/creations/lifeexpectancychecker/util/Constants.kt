package com.rfg.creations.lifeexpectancychecker.util

object Constants {
    object PrefKeys {
        const val PREF_NAME = "MyAppPref"
        const val SELECTED_THEME_KEY = "SelectedTheme"

    }
}