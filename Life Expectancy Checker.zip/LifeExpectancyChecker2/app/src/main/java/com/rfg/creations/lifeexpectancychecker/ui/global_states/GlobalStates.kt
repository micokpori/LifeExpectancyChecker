package com.rfg.creations.lifeexpectancychecker.ui.global_states

import android.content.Context
import com.rfg.creations.animenotepad.repository.preference_repository.UserPreferenceRepository
import com.rfg.creations.lifeexpectancychecker.R
import com.rfg.creations.lifeexpectancychecker.util.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

/**
 * This file stores global state values to be provided via dagger hilt
 * Global states are state values that leads to recomposition
 * but will be too cumbersome to be passed unto composable functions down the hierarchy
 * Example: Theme
 * passing theme down to settings screen will be too cumbersome therefore it is made a class that is
 * injected into the settings screen viewmodel
 */

class ThemeUiState @Inject constructor(
    userPreferenceRepository: UserPreferenceRepository,
    appContext: Context
) {
    private val prefKeys = Constants.PrefKeys
    private val _selectedTheme =
        MutableStateFlow(
            userPreferenceRepository.getStringPref(
                prefKeys.SELECTED_THEME_KEY, appContext.getString(
                    R.string.defaultTheme
                )
            )
        )
    val selectedTheme = _selectedTheme.asStateFlow()

    private val _darkTheme = MutableStateFlow(false)
    val darkTheme = _darkTheme.asStateFlow()

    private val _dynamicTheme = MutableStateFlow(false)
    val dynamicTheme = _dynamicTheme.asStateFlow()

    fun changeSelectedTheme(newThemeValue: String) {
        _selectedTheme.value = newThemeValue
    }

    fun changeDynamicTheme() {
        _dynamicTheme.value = !_dynamicTheme.value
    }

    fun changeDarkThemeValue(newThemeValue: Boolean) {
        _darkTheme.value = newThemeValue
    }
}